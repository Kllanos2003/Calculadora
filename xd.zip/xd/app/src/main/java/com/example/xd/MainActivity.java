package com.example.xd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView Resultado;

    EditText Num1;

    EditText Num2;

    Button Sumar;

    Button Restar;

    Button Multiplicar;

    Button Dividir;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Resultado = findViewById(R.id.resultado);
        Num1 = findViewById(R.id.num1);
        Num2 = findViewById(R.id.num2);
        Sumar = findViewById(R.id.suma);
        Restar = findViewById(R.id.resta);
        Multiplicar = findViewById(R.id.multiplicacion);
        Dividir = findViewById(R.id.division);
    }
}